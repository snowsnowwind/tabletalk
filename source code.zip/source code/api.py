# api.py
# TableTalk AI Recommendation API - FastAPI 服务
# 将推荐引擎包装为 Web API，供前端和团队调用

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from typing import Optional, List, Dict, Any
import uvicorn
import json

# 导入推荐引擎
from engine import RecommendationEngine

# ========== 创建 FastAPI 应用 ==========

app = FastAPI(
    title="TableTalk AI Recommendation API",
    description="AI驱动的餐厅推荐系统API，支持个性化推荐、用户画像、餐厅信息查询",
    version="1.0.0"
)

# ========== 配置 CORS（允许前端跨域访问） ==========

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # 生产环境建议指定具体域名
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# ========== 初始化推荐引擎 ==========

try:
    engine = RecommendationEngine(dataset_path="data/")
    print("[OK] 推荐引擎加载成功")
except Exception as e:
    print(f"[ERROR] 推荐引擎加载失败: {e}")
    engine = None

# ========== 定义请求/响应模型 ==========

class RecommendRequest(BaseModel):
    """推荐请求"""
    user_id: str
    top_n: Optional[int] = 5
    scenario: Optional[str] = None  # weekday, weekend, group, special
    context: Optional[Dict[str, Any]] = None


class RestaurantRecommendation(BaseModel):
    """餐厅推荐响应"""
    restaurant_id: str
    name: str
    cuisine_tags: List[str]
    rating: float
    price_range: int
    price_level: str
    location: Dict[str, Any]
    score: float
    reason: str
    match_percentage: int


class UserProfileResponse(BaseModel):
    """用户画像响应"""
    user_id: str
    demographics: Dict[str, Any]
    preferences: Dict[str, Any]
    behavior_patterns: Dict[str, Any]
    statistics: Dict[str, Any]
    created_at: str


class RestaurantInfoResponse(BaseModel):
    """餐厅信息响应"""
    restaurant_id: str
    name: str
    cuisine_tags: List[str]
    price_range: int
    price_level: str
    location: Dict[str, Any]
    features: Dict[str, Any]
    rating: float
    capacity: Dict[str, int]
    statistics: Dict[str, Any]
    created_at: str


class PopularRestaurantResponse(BaseModel):
    """热门餐厅响应"""
    restaurant_id: str
    name: str
    cuisine_tags: List[str]
    rating: float
    price_level: str
    score: float
    reason: str
    match_percentage: int


class StatisticsResponse(BaseModel):
    """系统统计响应"""
    total_users: int
    total_restaurants: int
    total_behaviors: int
    total_reservations: int
    users_with_reservations: int
    conversion_rate: float
    scenario_distribution: Dict[str, int]
    model: Dict[str, Any]


class FeedbackRequest(BaseModel):
    """用户反馈请求"""
    user_id: str
    restaurant_id: str
    action: str  # like, dislike, bookmark, share
    rating: Optional[int] = None  # 1-5


# ========== API 端点 ==========

@app.get("/")
async def root():
    """根路径 - 服务状态检查"""
    return {
        "message": "TableTalk AI Recommendation API",
        "status": "running",
        "version": "1.0.0",
        "docs": "/docs"
    }


@app.get("/health")
async def health_check():
    """健康检查"""
    if engine is None:
        return {"status": "unhealthy", "message": "Engine not initialized"}
    
    return {
        "status": "healthy",
        "users": len(engine.users),
        "restaurants": len(engine.restaurants),
        "behaviors": len(engine.behaviors)
    }


@app.post("/recommend", response_model=List[RestaurantRecommendation])
async def get_recommendations(request: RecommendRequest):
    """
    获取个性化推荐
    
    - **user_id**: 用户ID (必填)
    - **top_n**: 推荐数量 (默认5)
    - **scenario**: 场景类型 (weekday/weekend/group/special)
    - **context**: 额外上下文信息
    """
    if engine is None:
        raise HTTPException(status_code=503, detail="Engine not initialized")
    
    try:
        results = engine.recommend(
            user_id=request.user_id,
            top_n=request.top_n,
            scenario=request.scenario,
            context=request.context
        )
        return results
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.get("/user/{user_id}", response_model=UserProfileResponse)
async def get_user_profile(user_id: str):
    """
    获取用户画像
    
    - **user_id**: 用户ID
    """
    if engine is None:
        raise HTTPException(status_code=503, detail="Engine not initialized")
    
    profile = engine.get_user_profile(user_id)
    
    if profile is None:
        raise HTTPException(status_code=404, detail=f"User {user_id} not found")
    
    return profile


@app.get("/restaurant/{restaurant_id}", response_model=RestaurantInfoResponse)
async def get_restaurant_info(restaurant_id: str):
    """
    获取餐厅详细信息
    
    - **restaurant_id**: 餐厅ID
    """
    if engine is None:
        raise HTTPException(status_code=503, detail="Engine not initialized")
    
    info = engine.get_restaurant_info(restaurant_id)
    
    if info is None:
        raise HTTPException(status_code=404, detail=f"Restaurant {restaurant_id} not found")
    
    return info


@app.get("/popular", response_model=List[PopularRestaurantResponse])
async def get_popular_recommendations(top_n: int = 5):
    """
    获取热门推荐（用于新用户冷启动）
    
    - **top_n**: 推荐数量 (默认5)
    """
    if engine is None:
        raise HTTPException(status_code=503, detail="Engine not initialized")
    
    return engine.get_popular_recommendations(top_n)


@app.get("/statistics", response_model=StatisticsResponse)
async def get_system_statistics():
    """获取系统统计信息"""
    if engine is None:
        raise HTTPException(status_code=503, detail="Engine not initialized")
    
    return engine.get_statistics()


@app.get("/users")
async def get_all_users(limit: int = 20):
    """获取用户列表（分页）"""
    if engine is None:
        raise HTTPException(status_code=503, detail="Engine not initialized")
    
    users = engine.users[:limit]
    return {
        "total": len(engine.users),
        "limit": limit,
        "users": users
    }


@app.get("/restaurants")
async def get_all_restaurants(limit: int = 20):
    """获取餐厅列表（分页）"""
    if engine is None:
        raise HTTPException(status_code=503, detail="Engine not initialized")
    
    restaurants = engine.restaurants[:limit]
    return {
        "total": len(engine.restaurants),
        "limit": limit,
        "restaurants": restaurants
    }


@app.post("/feedback")
async def record_feedback(request: FeedbackRequest):
    """
    记录用户反馈（用于后续优化）
    
    - **user_id**: 用户ID
    - **restaurant_id**: 餐厅ID
    - **action**: 行为类型 (like/dislike/bookmark/share)
    - **rating**: 评分 (1-5)
    """
    # 这里是示例实现，实际可以记录到数据库
    feedback = {
        "user_id": request.user_id,
        "restaurant_id": request.restaurant_id,
        "action": request.action,
        "rating": request.rating,
        "timestamp": "now"
    }
    
    # 可以保存到文件或数据库
    try:
        with open("data/feedback.json", "a", encoding="utf-8") as f:
            f.write(json.dumps(feedback) + "\n")
    except Exception as e:
        return {"status": "error", "message": str(e)}
    
    return {"status": "success", "message": "Feedback recorded"}


@app.get("/test/{user_id}")
async def test_recommendation(user_id: str):
    """
    测试推荐功能（调试用）
    
    - **user_id**: 用户ID
    """
    if engine is None:
        raise HTTPException(status_code=503, detail="Engine not initialized")
    
    # 测试三种场景
    results = {
        "user_id": user_id,
        "weekday": engine.recommend(user_id, top_n=3, scenario="weekday"),
        "weekend": engine.recommend(user_id, top_n=3, scenario="weekend"),
        "group": engine.recommend(user_id, top_n=3, scenario="group"),
        "special": engine.recommend(user_id, top_n=3, scenario="special")
    }
    
    return results


# ========== 启动入口 ==========

if __name__ == "__main__":
    print("=" * 70)
    print("Starting TableTalk AI Recommendation API Server")
    print("=" * 70)
    
    uvicorn.run(
        "api:app",
        host="0.0.0.0",
        port=8000,
        reload=True,
        log_level="info"
    )