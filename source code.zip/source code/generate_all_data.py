# generate_all_data.py - 完整数据生成脚本
# 复制这段代码到新的Python文件中运行

import json
import random
import uuid
from datetime import datetime, timedelta
from faker import Faker

# 初始化
fake = Faker('zh_CN')

print("=" * 70)
print("TableTalk 数据生成器")
print("=" * 70)

# ========== 配置 ==========
CONFIG = {
    "num_users": 50,
    "num_restaurants": 30,
    "behaviors_per_user": (8, 25),  # 每个用户的行为数量范围
    "scenarios": ["weekday", "weekend", "group", "special"]
}

# ========== 定义数据 ==========
CUISINES = ["Italian", "Chinese", "Japanese", "Mexican", "American", 
           "French", "Thai", "Indian", "Korean", "Mediterranean"]

DISTRICTS = ["Financial District", "Midtown", "West Village", "East Village",
            "Chelsea", "Upper East Side", "Upper West Side", "SoHo"]

OCCUPATIONS = ["Software Engineer", "Marketing Manager", "Teacher", "Doctor", "Student"]
AGE_GROUPS = ["18-24", "25-34", "35-44", "45-54", "55+"]
INCOME_LEVELS = ["low", "middle", "high"]

BEHAVIOR_TYPES = [
    "VIEW_RESTAURANT",
    "VIEW_MENU",
    "READ_REVIEWS",
    "CHECK_AVAILABILITY",
    "MAKE_RESERVATION",
    "SAVE_TO_FAVORITES",
    "CANCEL_RESERVATION",
    "LEAVE_REVIEW",
    "SHARE_RESTAURANT",
    "CLICK_RECOMMENDATION"
]

# ========== 生成餐厅 ==========
def generate_restaurants(n=30):
    print(f"\n生成 {n} 家餐厅...")
    restaurants = []
    
    for i in range(n):
        cuisine = random.choice(CUISINES)
        
        restaurant = {
            "restaurant_id": f"REST_{i:04d}",
            "name": f"{random.choice(['The', 'Grand', 'Royal', 'New'])} {cuisine} {random.choice(['Restaurant', 'Bistro', 'Grill', 'Cafe'])}",
            "cuisine_tags": [cuisine] + random.sample([c for c in CUISINES if c != cuisine], random.randint(0, 2)),
            "price_range": random.randint(1, 5),
            "location": {
                "district": random.choice(DISTRICTS),
                "latitude": 40.7 + random.uniform(-0.1, 0.1),
                "longitude": -74.0 + random.uniform(-0.1, 0.1)
            },
            "features": {
                "ambiance": random.sample(["Romantic", "Business", "Casual", "Trendy", "Cozy", "Family"], random.randint(2, 4)),
                "dietary": random.sample(["Vegetarian", "Gluten-Free", "Vegan", "Halal"], random.randint(0, 2)),
                "facilities": random.sample(["Outdoor Seating", "Parking", "WiFi", "Private Room", "Bar"], random.randint(2, 4))
            },
            "rating": round(random.uniform(3.0, 5.0), 1),
            "capacity": {
                "min": random.choice([2, 4]),
                "max": random.choice([10, 20, 30, 40, 50])
            },
            "created_at": fake.date_time_between(start_date="-1y", end_date="now").isoformat()
        }
        restaurants.append(restaurant)
    
    print(f"  生成了 {len(restaurants)} 家餐厅")
    return restaurants

# ========== 生成用户 ==========
def generate_users(n=50):
    print(f"\n生成 {n} 个用户...")
    users = []
    
    for i in range(n):
        # 生成随机偏好权重
        cuisine_weights = {}
        for cuisine in CUISINES:
            if random.random() < 0.3:  # 30%的概率有高偏好
                weight = random.uniform(0.7, 1.0)
            elif random.random() < 0.5:  # 50%的概率有中等偏好
                weight = random.uniform(0.3, 0.7)
            else:  # 20%的概率有低偏好
                weight = random.uniform(0.0, 0.3)
            cuisine_weights[cuisine] = round(weight, 2)
        
        user = {
            "user_id": f"USER_{i:04d}",
            "demographics": {
                "age_group": random.choice(AGE_GROUPS),
                "occupation": random.choice(OCCUPATIONS),
                "income_level": random.choice(INCOME_LEVELS),
                "gender": random.choice(["male", "female"]),
                "marital_status": random.choice(["single", "married", "divorced"]),
                "has_children": random.choice([True, False])
            },
            "preferences": {
                "cuisine_weights": cuisine_weights,
                "price_sensitivity": round(random.uniform(0.0, 1.0), 2),
                "location_range_km": random.choice([3, 5, 10, 15]),
                "time_preferences": {
                    "weekday_lunch": round(random.uniform(0.3, 0.9), 2),
                    "weekday_dinner": round(random.uniform(0.5, 1.0), 2),
                    "weekend_brunch": round(random.uniform(0.2, 0.8), 2),
                    "weekend_dinner": round(random.uniform(0.6, 1.0), 2)
                }
            },
            "behavior_patterns": {
                "frequency_per_month": random.randint(1, 10),
                "group_size_distribution": {
                    "solo": round(random.uniform(0.1, 0.4), 2),
                    "couple": round(random.uniform(0.2, 0.5), 2),
                    "group": round(random.uniform(0.1, 0.4), 2)
                }
            },
            "created_at": fake.date_time_between(start_date="-6m", end_date="now").isoformat()
        }
        users.append(user)
    
    print(f"  生成了 {len(users)} 个用户")
    return users

# ========== 生成行为 ==========
def generate_behaviors(users, restaurants):
    print(f"\n生成用户行为...")
    behaviors = []
    sessions = []
    reservations = []
    
    for user in users:
        user_id = user["user_id"]
        # 每个用户生成的行为数
        num_behaviors = random.randint(CONFIG["behaviors_per_user"][0], CONFIG["behaviors_per_user"][1])
        
        # 为每个用户生成多个会话
        num_sessions = random.randint(2, 6)
        
        for session_idx in range(num_sessions):
            session_id = f"SESS_{user_id}_{session_idx:03d}"
            
            # 选择场景
            scenario = random.choice(CONFIG["scenarios"])
            
            # 选择餐厅（根据用户偏好选择）
            user_prefs = user["preferences"]["cuisine_weights"]
            candidate_restaurants = []
            
            for restaurant in restaurants:
                # 计算匹配分数
                match_score = 0
                for cuisine in restaurant["cuisine_tags"]:
                    match_score += user_prefs.get(cuisine, 0)
                candidate_restaurants.append((restaurant, match_score))
            
            # 按匹配度排序
            candidate_restaurants.sort(key=lambda x: x[1], reverse=True)
            
            # 从前5个中选择
            if len(candidate_restaurants) > 5:
                top_restaurants = [r[0] for r in candidate_restaurants[:5]]
            else:
                top_restaurants = [r[0] for r in candidate_restaurants]
            
            # 根据场景调整选择概率
            if scenario == "group":
                # 团体场景选容量大的
                group_restaurants = [r for r in top_restaurants if r["capacity"]["max"] >= 8]
                if group_restaurants:
                    restaurant = random.choice(group_restaurants)
                else:
                    restaurant = random.choice(top_restaurants) if top_restaurants else random.choice(restaurants)
            elif scenario == "special":
                # 特殊场合选评分高的
                if top_restaurants:
                    restaurant = max(top_restaurants, key=lambda r: r["rating"])
                else:
                    restaurant = random.choice(restaurants)
            else:
                restaurant = random.choice(top_restaurants) if top_restaurants else random.choice(restaurants)
            
            # 生成会话时间
            session_time = fake.date_time_between(start_date="-3m", end_date="now")
            
            # 生成行为序列
            num_actions = random.randint(2, 7)
            action_sequence = ["VIEW_RESTAURANT"]
            
            # 中间行为
            middle_actions = ["VIEW_MENU", "READ_REVIEWS", "CHECK_AVAILABILITY"]
            if num_actions > 2:
                action_sequence.extend(random.sample(middle_actions, min(num_actions-2, len(middle_actions))))
            
            # 最终行为
            if random.random() < 0.4:  # 40%的转化率
                action_sequence.append("MAKE_RESERVATION")
            elif random.random() < 0.6:
                action_sequence.append("SAVE_TO_FAVORITES")
            
            # 生成行为记录
            session_behaviors = []
            current_time = session_time
            for action_idx, action in enumerate(action_sequence):
                # 行为持续时间
                duration_ranges = {
                    "VIEW_RESTAURANT": (20, 120),
                    "VIEW_MENU": (30, 180),
                    "READ_REVIEWS": (60, 300),
                    "CHECK_AVAILABILITY": (10, 60),
                    "MAKE_RESERVATION": (60, 300),
                    "SAVE_TO_FAVORITES": (5, 20),
                    "CANCEL_RESERVATION": (20, 60),
                    "LEAVE_REVIEW": (120, 600),
                    "SHARE_RESTAURANT": (10, 30),
                    "CLICK_RECOMMENDATION": (5, 15)
                }
                duration_range = duration_ranges.get(action, (10, 60))
                duration = random.randint(duration_range[0], duration_range[1])
                
                behavior = {
                    "behavior_id": str(uuid.uuid4()),
                    "user_id": user_id,
                    "restaurant_id": restaurant["restaurant_id"],
                    "action_type": action,
                    "timestamp": current_time.isoformat(),
                    "duration_seconds": duration,
                    "metadata": {
                        "session_index": action_idx,
                        "total_actions": len(action_sequence),
                        "device": random.choice(["mobile", "desktop", "tablet"])
                    },
                    "scenario": scenario,
                    "session_id": session_id
                }
                
                session_behaviors.append(behavior)
                current_time += timedelta(seconds=duration + random.randint(5, 30))
            
            behaviors.extend(session_behaviors)
            
            # 创建会话记录
            session = {
                "session_id": session_id,
                "user_id": user_id,
                "restaurant_id": restaurant["restaurant_id"],
                "scenario": scenario,
                "start_time": session_behaviors[0]["timestamp"] if session_behaviors else session_time.isoformat(),
                "end_time": session_behaviors[-1]["timestamp"] if session_behaviors else session_time.isoformat(),
                "behaviors_count": len(session_behaviors),
                "final_status": "reserved" if any(b["action_type"] == "MAKE_RESERVATION" for b in session_behaviors) else "browsed"
            }
            sessions.append(session)
            
            # 如果有预订，生成预订记录
            if session["final_status"] == "reserved":
                # 找到预订行为的时间
                reservation_behavior = next((b for b in session_behaviors if b["action_type"] == "MAKE_RESERVATION"), None)
                if reservation_behavior:
                    reservation_time = datetime.fromisoformat(reservation_behavior["timestamp"])
                    # 预订时间通常是未来的某天
                    meal_time = reservation_time + timedelta(
                        days=random.randint(1, 14),
                        hours=random.randint(1, 48)
                    )
                    
                    reservation = {
                        "reservation_id": str(uuid.uuid4()),
                        "user_id": user_id,
                        "restaurant_id": restaurant["restaurant_id"],
                        "reservation_time": meal_time.isoformat(),
                        "party_size": random.randint(1, 8),
                        "status": random.choice(["confirmed", "completed", "cancelled"]),
                        "created_at": reservation_time.isoformat(),
                        "metadata": {
                            "session_id": session_id,
                            "source": "ai_recommendation",
                            "special_requests": random.choice(["", "Window seat", "Birthday cake", "Allergy alert"])
                        }
                    }
                    reservations.append(reservation)
    
    print(f"  生成了 {len(behaviors)} 条行为")
    print(f"  生成了 {len(sessions)} 个会话")
    print(f"  生成了 {len(reservations)} 条预订")
    
    return behaviors, sessions, reservations

# ========== 主函数 ==========
def main():
    print("\n开始生成数据...")
    print("=" * 70)
    
    # 1. 生成餐厅
    restaurants = generate_restaurants(CONFIG["num_restaurants"])
    
    # 2. 生成用户
    users = generate_users(CONFIG["num_users"])
    
    # 3. 生成行为
    behaviors, sessions, reservations = generate_behaviors(users, restaurants)
    
    # 4. 保存数据
    print("\n保存数据到文件...")
    
    # 创建 data 文件夹
    import os
    os.makedirs("data", exist_ok=True)
    
    # 保存所有数据
    data_files = {
        "restaurants": restaurants,
        "users": users,
        "behaviors": behaviors,
        "sessions": sessions,
        "reservations": reservations
    }
    
    for name, data in data_files.items():
        with open(f"data/{name}.json", "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
        print(f"  已保存: data/{name}.json ({len(data)} 条)")
    
    # 5. 生成统计信息
    print("\n" + "=" * 70)
    print("数据生成完成！统计信息：")
    print("=" * 70)
    print(f"  餐厅: {len(restaurants)} 家")
    print(f"  用户: {len(users)} 个")
    print(f"  行为: {len(behaviors)} 条")
    print(f"  会话: {len(sessions)} 个")
    print(f"  预订: {len(reservations)} 条")
    
    # 计算转化率
    users_with_reservations = len(set([r["user_id"] for r in reservations]))
    conversion_rate = users_with_reservations / len(users) if users else 0
    print(f"  转化率: {conversion_rate:.1%}")
    
    print("\n数据文件保存在 data/ 文件夹中")
    print("=" * 70)

if __name__ == "__main__":
    main()