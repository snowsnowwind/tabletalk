# test_engine.py - 测试推荐引擎
from engine import RecommendationEngine

print("=" * 70)
print("测试推荐引擎")
print("=" * 70)

# 初始化引擎（从文件加载数据）
engine = RecommendationEngine(dataset_path="data/")

# 测试推荐
if engine.users:
    test_user = engine.users[0]["user_id"]
    print(f"\n测试用户: {test_user}")
    
    # 获取推荐
    recommendations = engine.recommend(test_user, top_n=5)
    
    print("\n推荐结果:")
    for i, rec in enumerate(recommendations, 1):
        print(f"  {i}. {rec['name']}")
        print(f"     菜系: {', '.join(rec['cuisine_tags'])}")
        print(f"     评分: {rec['rating']}, 价格: {rec['price_level']}")
        print(f"     匹配度: {rec['match_percentage']}%")
        print(f"     理由: {rec['reason']}")
        print()

print("=" * 70)