# generate_large_dataset.py
# 生成大规模数据集 - 500用户，200餐厅，~15000行为

import json
import random
import uuid
import os
from datetime import datetime, timedelta
from faker import Faker

# 初始化
fake = Faker('zh_CN')

# 修复Windows控制台编码问题
import sys
import io
if sys.platform == 'win32':
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8')

print("=" * 70)
print("TableTalk Large Dataset Generator")
print("=" * 70)

# ========== Large Scale Configuration ==========
CONFIG = {
    "num_users": 500,              # 500 users
    "num_restaurants": 200,        # 200 restaurants
    "behaviors_per_user": (15, 50), # 15-50 behaviors per user
    "scenarios": ["weekday", "weekend", "group", "special"]
}

# ========== Define Data ==========
CUISINES = ["Italian", "Chinese", "Japanese", "Mexican", "American", 
           "French", "Thai", "Indian", "Korean", "Mediterranean",
           "Spanish", "German", "Vietnamese", "Greek", "Turkish"]

DISTRICTS = ["Financial District", "Midtown", "West Village", "East Village",
            "Chelsea", "Upper East Side", "Upper West Side", "SoHo",
            "Tribeca", "Williamsburg", "Greenwich Village", "Harlem",
            "Brooklyn Heights", "DUMBO", "Park Slope", "Astoria"]

OCCUPATIONS = ["Software Engineer", "Marketing Manager", "Teacher", "Doctor", 
              "Student", "Financial Analyst", "Consultant", "Designer",
              "Sales Executive", "Entrepreneur", "Researcher", "Artist",
              "Lawyer", "Architect", "Pharmacist", "Dentist"]

AGE_GROUPS = ["18-24", "25-34", "35-44", "45-54", "55+"]
INCOME_LEVELS = ["low", "middle", "high"]

BEHAVIOR_TYPES = [
    "VIEW_RESTAURANT",
    "VIEW_MENU",
    "READ_REVIEWS",
    "CHECK_AVAILABILITY",
    "MAKE_RESERVATION",
    "SAVE_TO_FAVORITES",
    "CANCEL_RESERVATION",
    "LEAVE_REVIEW",
    "SHARE_RESTAURANT",
    "CLICK_RECOMMENDATION"
]

# ========== Generate Restaurants ==========
def generate_restaurants(n=200):
    print(f"\n[1/4] Generating {n} restaurants...")
    restaurants = []
    
    prefixes = ["The", "Grand", "Royal", "New", "Old", "Golden", "Silver", 
                "Blue", "Green", "Red", "White", "Black", "Rose", "Lily",
                "Star", "Moon", "Sun", "Garden", "Palace", "House"]
    
    suffixes = ["Restaurant", "Bistro", "Grill", "Cafe", "Kitchen", "Table",
                "Dining", "Tavern", "Inn", "Lounge", "Bar & Grill", "Eatery"]
    
    for i in range(n):
        cuisine = random.choice(CUISINES)
        name = f"{random.choice(prefixes)} {cuisine} {random.choice(suffixes)}"
        
        restaurant = {
            "restaurant_id": f"REST_{i:04d}",
            "name": name,
            "cuisine_tags": [cuisine] + random.sample([c for c in CUISINES if c != cuisine], 
                                                       random.randint(0, 3)),
            "price_range": random.randint(1, 5),
            "location": {
                "district": random.choice(DISTRICTS),
                "latitude": 40.7 + random.uniform(-0.15, 0.15),
                "longitude": -74.0 + random.uniform(-0.15, 0.15)
            },
            "features": {
                "ambiance": random.sample(["Romantic", "Business", "Casual", "Trendy", 
                                          "Cozy", "Family", "Elegant", "Vibrant", 
                                          "Quiet", "Rustic"], random.randint(2, 5)),
                "dietary": random.sample(["Vegetarian", "Gluten-Free", "Vegan", "Halal", 
                                         "Kosher", "Dairy-Free"], random.randint(0, 3)),
                "facilities": random.sample(["Outdoor Seating", "Parking", "WiFi", 
                                            "Private Room", "Bar", "Live Music", 
                                            "Takeaway", "Delivery"], random.randint(2, 5))
            },
            "rating": round(random.uniform(3.0, 5.0), 1),
            "capacity": {
                "min": random.choice([2, 4, 6]),
                "max": random.choice([10, 20, 30, 40, 50, 60, 80, 100])
            },
            "created_at": fake.date_time_between(start_date="-2y", end_date="now").isoformat()
        }
        restaurants.append(restaurant)
    
    print(f"  [OK] Generated {len(restaurants)} restaurants")
    return restaurants

# ========== Generate Users ==========
def generate_users(n=500):
    print(f"\n[2/4] Generating {n} users...")
    users = []
    
    for i in range(n):
        cuisine_weights = {}
        high_pref_count = random.randint(3, 6)
        high_pref_cuisines = random.sample(CUISINES, min(high_pref_count, len(CUISINES)))
        
        for cuisine in CUISINES:
            if cuisine in high_pref_cuisines:
                weight = round(random.uniform(0.6, 1.0), 2)
            else:
                weight = round(random.uniform(0.0, 0.4), 2)
            cuisine_weights[cuisine] = weight
        
        user = {
            "user_id": f"USER_{i:04d}",
            "demographics": {
                "age_group": random.choice(AGE_GROUPS),
                "occupation": random.choice(OCCUPATIONS),
                "income_level": random.choice(INCOME_LEVELS),
                "gender": random.choice(["male", "female", "non-binary"]),
                "marital_status": random.choice(["single", "married", "divorced", "widowed"]),
                "has_children": random.choice([True, False])
            },
            "preferences": {
                "cuisine_weights": cuisine_weights,
                "price_sensitivity": round(random.uniform(0.0, 1.0), 2),
                "location_range_km": random.choice([2, 3, 5, 8, 10, 15, 20]),
                "time_preferences": {
                    "weekday_lunch": round(random.uniform(0.2, 0.9), 2),
                    "weekday_dinner": round(random.uniform(0.4, 1.0), 2),
                    "weekend_brunch": round(random.uniform(0.1, 0.8), 2),
                    "weekend_dinner": round(random.uniform(0.5, 1.0), 2)
                },
                "ambiance_preferences": {
                    "romantic": round(random.uniform(0, 1), 2),
                    "business": round(random.uniform(0, 1), 2),
                    "casual": round(random.uniform(0, 1), 2),
                    "trendy": round(random.uniform(0, 1), 2),
                    "cozy": round(random.uniform(0, 1), 2)
                }
            },
            "behavior_patterns": {
                "frequency_per_month": random.randint(2, 15),
                "group_size_distribution": {
                    "solo": round(random.uniform(0.05, 0.40), 2),
                    "couple": round(random.uniform(0.15, 0.50), 2),
                    "small_group": round(random.uniform(0.10, 0.40), 2),
                    "large_group": round(random.uniform(0.0, 0.20), 2)
                },
                "preferred_payment": random.choice(["credit_card", "mobile_pay", "cash", "crypto"]),
                "review_probability": round(random.uniform(0.05, 0.60), 2)
            },
            "created_at": fake.date_time_between(start_date="-1y", end_date="now").isoformat()
        }
        users.append(user)
    
    print(f"  [OK] Generated {len(users)} users")
    return users

# ========== Generate Behaviors ==========
def generate_behaviors(users, restaurants):
    print(f"\n[3/4] Generating user behaviors...")
    behaviors = []
    sessions = []
    reservations = []
    
    behavior_count = 0
    session_count = 0
    
    for user_idx, user in enumerate(users):
        user_id = user["user_id"]
        num_behaviors = random.randint(CONFIG["behaviors_per_user"][0], CONFIG["behaviors_per_user"][1])
        num_sessions = random.randint(3, 10)
        
        for session_idx in range(num_sessions):
            session_id = f"SESS_{user_id}_{session_idx:03d}"
            scenario = random.choice(CONFIG["scenarios"])
            
            user_prefs = user["preferences"]["cuisine_weights"]
            candidate_restaurants = []
            
            for restaurant in restaurants:
                match_score = 0
                for cuisine in restaurant["cuisine_tags"]:
                    match_score += user_prefs.get(cuisine, 0)
                candidate_restaurants.append((restaurant, match_score))
            
            candidate_restaurants.sort(key=lambda x: x[1], reverse=True)
            
            if len(candidate_restaurants) > 10:
                top_restaurants = [r[0] for r in candidate_restaurants[:10]]
            else:
                top_restaurants = [r[0] for r in candidate_restaurants]
            
            if scenario == "group":
                group_restaurants = [r for r in top_restaurants if r["capacity"]["max"] >= 8]
                restaurant = random.choice(group_restaurants) if group_restaurants else random.choice(top_restaurants)
            elif scenario == "special":
                restaurant = max(top_restaurants, key=lambda r: r["rating"]) if top_restaurants else random.choice(restaurants)
            else:
                restaurant = random.choice(top_restaurants) if top_restaurants else random.choice(restaurants)
            
            session_time = fake.date_time_between(start_date="-6m", end_date="now")
            num_actions = random.randint(3, 10)
            action_sequence = ["VIEW_RESTAURANT"]
            
            middle_actions = ["VIEW_MENU", "READ_REVIEWS", "CHECK_AVAILABILITY", "SAVE_TO_FAVORITES"]
            if num_actions > 2:
                action_sequence.extend(random.sample(middle_actions, min(num_actions-2, len(middle_actions))))
            
            if scenario == "group":
                conversion_rate = 0.50
            elif scenario == "special":
                conversion_rate = 0.45
            elif scenario == "weekend":
                conversion_rate = 0.40
            else:
                conversion_rate = 0.35
            
            if random.random() < conversion_rate:
                action_sequence.append("MAKE_RESERVATION")
            elif random.random() < 0.5:
                action_sequence.append("SAVE_TO_FAVORITES")
            
            session_behaviors = []
            current_time = session_time
            
            for action_idx, action in enumerate(action_sequence):
                duration_ranges = {
                    "VIEW_RESTAURANT": (15, 120),
                    "VIEW_MENU": (30, 200),
                    "READ_REVIEWS": (60, 400),
                    "CHECK_AVAILABILITY": (10, 60),
                    "MAKE_RESERVATION": (60, 350),
                    "SAVE_TO_FAVORITES": (5, 25),
                    "CANCEL_RESERVATION": (20, 60),
                    "LEAVE_REVIEW": (120, 700),
                    "SHARE_RESTAURANT": (10, 35),
                    "CLICK_RECOMMENDATION": (5, 15)
                }
                duration_range = duration_ranges.get(action, (10, 60))
                duration = random.randint(duration_range[0], duration_range[1])
                
                behavior = {
                    "behavior_id": str(uuid.uuid4()),
                    "user_id": user_id,
                    "restaurant_id": restaurant["restaurant_id"],
                    "action_type": action,
                    "timestamp": current_time.isoformat(),
                    "duration_seconds": duration,
                    "metadata": {
                        "session_index": action_idx,
                        "total_actions": len(action_sequence),
                        "device": random.choice(["mobile", "desktop", "tablet"]),
                        "browser": random.choice(["Chrome", "Safari", "Firefox", "Edge"])
                    },
                    "scenario": scenario,
                    "session_id": session_id
                }
                
                session_behaviors.append(behavior)
                current_time += timedelta(seconds=duration + random.randint(5, 45))
                behavior_count += 1
            
            behaviors.extend(session_behaviors)
            
            session = {
                "session_id": session_id,
                "user_id": user_id,
                "restaurant_id": restaurant["restaurant_id"],
                "scenario": scenario,
                "start_time": session_behaviors[0]["timestamp"] if session_behaviors else session_time.isoformat(),
                "end_time": session_behaviors[-1]["timestamp"] if session_behaviors else session_time.isoformat(),
                "behaviors_count": len(session_behaviors),
                "final_status": "reserved" if any(b["action_type"] == "MAKE_RESERVATION" for b in session_behaviors) else "browsed",
                "device": random.choice(["mobile", "desktop", "tablet"])
            }
            sessions.append(session)
            session_count += 1
            
            if session["final_status"] == "reserved":
                reservation_behavior = next((b for b in session_behaviors if b["action_type"] == "MAKE_RESERVATION"), None)
                if reservation_behavior:
                    reservation_time = datetime.fromisoformat(reservation_behavior["timestamp"])
                    meal_time = reservation_time + timedelta(
                        days=random.randint(1, 21),
                        hours=random.randint(1, 72)
                    )
                    
                    reservation = {
                        "reservation_id": str(uuid.uuid4()),
                        "user_id": user_id,
                        "restaurant_id": restaurant["restaurant_id"],
                        "reservation_time": meal_time.isoformat(),
                        "party_size": random.randint(1, 12),
                        "status": random.choice(["confirmed", "completed", "cancelled", "no_show"]),
                        "created_at": reservation_time.isoformat(),
                        "metadata": {
                            "session_id": session_id,
                            "source": random.choice(["ai_recommendation", "search", "direct"]),
                            "special_requests": random.choice(["", "Window seat", "Birthday cake", "Allergy alert", 
                                                              "Private room", "Wheelchair access", "High chair needed"])
                        }
                    }
                    reservations.append(reservation)
    
    print(f"  [OK] Generated {len(behaviors)} behaviors")
    print(f"  [OK] Generated {len(sessions)} sessions")
    print(f"  [OK] Generated {len(reservations)} reservations")
    
    return behaviors, sessions, reservations

# ========== Main Function ==========
def main():
    print("\nGenerating large dataset...")
    print("=" * 70)
    
    # 1. Generate Restaurants
    restaurants = generate_restaurants(CONFIG["num_restaurants"])
    
    # 2. Generate Users
    users = generate_users(CONFIG["num_users"])
    
    # 3. Generate Behaviors
    behaviors, sessions, reservations = generate_behaviors(users, restaurants)
    
    # 4. Save Data
    print("\n[4/4] Saving data to files...")
    
    os.makedirs("data", exist_ok=True)
    
    data_files = {
        "restaurants": restaurants,
        "users": users,
        "behaviors": behaviors,
        "sessions": sessions,
        "reservations": reservations
    }
    
    file_sizes = {}
    for name, data in data_files.items():
        file_path = f"data/{name}.json"
        with open(file_path, "w", encoding="utf-8") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
        file_size = os.path.getsize(file_path) / 1024
        file_sizes[name] = file_size
        print(f"  [OK] Saved: data/{name}.json ({len(data)} records, {file_size:.1f} KB)")
    
    # 5. Statistics
    print("\n" + "=" * 70)
    print("Dataset Generation Complete!")
    print("=" * 70)
    
    users_with_reservations = len(set([r["user_id"] for r in reservations]))
    conversion_rate = users_with_reservations / len(users) if users else 0
    
    scenario_dist = {}
    for session in sessions:
        scenario = session.get("scenario", "unknown")
        scenario_dist[scenario] = scenario_dist.get(scenario, 0) + 1
    
    action_dist = {}
    for behavior in behaviors:
        action = behavior["action_type"]
        action_dist[action] = action_dist.get(action, 0) + 1
    
    print("\nData Statistics:")
    print(f"  Users: {len(users)}")
    print(f"  Restaurants: {len(restaurants)}")
    print(f"  Behaviors: {len(behaviors)}")
    print(f"  Sessions: {len(sessions)}")
    print(f"  Reservations: {len(reservations)}")
    print(f"  Conversion Rate: {conversion_rate:.1%}")
    print(f"  Total File Size: {sum(file_sizes.values()):.1f} KB")
    
    print("\nScenario Distribution:")
    for scenario, count in sorted(scenario_dist.items(), key=lambda x: x[1], reverse=True):
        print(f"  {scenario}: {count} ({count/len(sessions)*100:.1f}%)")
    
    print("\nBehavior Type Distribution:")
    for action, count in sorted(action_dist.items(), key=lambda x: x[1], reverse=True):
        print(f"  {action}: {count} ({count/len(behaviors)*100:.1f}%)")
    
    print("\n" + "=" * 70)
    print("[OK] Data saved to data/ folder")
    print("=" * 70)

if __name__ == "__main__":
    main()