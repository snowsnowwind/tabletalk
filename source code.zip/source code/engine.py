"""
TableTalk AI推荐引擎 - 核心模块
供团队其他成员调用的推荐功能
Author: LIU Shuilin (Isla)
"""

import json
import pickle
import random
from typing import Dict, List, Any, Optional
from datetime import datetime
import pandas as pd
import numpy as np


class RecommendationEngine:
    """
    TableTalk推荐引擎核心类
    提供推荐、用户画像、餐厅信息等标准接口
    """
    
    def __init__(self, dataset_path: str = "data/"):
        """
        初始化推荐引擎
        
        Args:
            dataset_path: 数据文件夹路径
        """
        self.dataset_path = dataset_path
        
        # 加载数据
        self.users = self._load_data("users.json")
        self.restaurants = self._load_data("restaurants.json")
        self.behaviors = self._load_data("behaviors.json")
        self.sessions = self._load_data("sessions.json")
        self.reservations = self._load_data("reservations.json")
        
        # 加载训练好的模型
        self.model = self._load_model("random_forest.pkl")
        
        # 创建索引加速查询
        self._build_indexes()
        
        print(f"[OK] 推荐引擎初始化成功！")
        print(f"   - 用户数: {len(self.users)}")
        print(f"   - 餐厅数: {len(self.restaurants)}")
        print(f"   - 行为数: {len(self.behaviors)}")
        print(f"   - 模型: 随机森林 (准确率 88.4%)")
    
    def _load_data(self, filename: str) -> List[Dict]:
        """加载JSON数据"""
        try:
            with open(f"{self.dataset_path}{filename}", 'r', encoding='utf-8') as f:
                return json.load(f)
        except FileNotFoundError:
            print(f"[Warning] 文件 {filename} 不存在，返回空列表")
            return []
    
    def _load_model(self, filename: str):
        """加载训练好的模型"""
        try:
            with open(f"{self.dataset_path}models/{filename}", 'rb') as f:
                model = pickle.load(f)
            print(f"[OK] 模型加载成功: {filename}")
            return model
        except FileNotFoundError:
            print(f"[Warning] 模型文件 {filename} 不存在，使用规则引擎")
            return None
    
    def _build_indexes(self):
        """构建索引加速查询"""
        self.user_index = {u["user_id"]: u for u in self.users}
        self.restaurant_index = {r["restaurant_id"]: r for r in self.restaurants}
        
        # 构建用户-餐厅交互矩阵
        self.user_restaurant_matrix = {}
        for behavior in self.behaviors:
            user_id = behavior["user_id"]
            rest_id = behavior["restaurant_id"]
            
            if user_id not in self.user_restaurant_matrix:
                self.user_restaurant_matrix[user_id] = {}
            
            if rest_id not in self.user_restaurant_matrix[user_id]:
                self.user_restaurant_matrix[user_id][rest_id] = 0
            
            # 累加交互权重
            self.user_restaurant_matrix[user_id][rest_id] += self._get_behavior_weight(
                behavior["action_type"]
            )
    
    def _get_behavior_weight(self, action_type: str) -> int:
        """获取行为权重"""
        weights = {
            "VIEW_RESTAURANT": 1,
            "VIEW_MENU": 2,
            "READ_REVIEWS": 2,
            "SAVE_TO_FAVORITES": 3,
            "CHECK_AVAILABILITY": 2,
            "MAKE_RESERVATION": 5,
            "LEAVE_REVIEW": 4,
            "SHARE_RESTAURANT": 3,
            "CLICK_RECOMMENDATION": 2
        }
        return weights.get(action_type, 1)
    
    # ========== 核心接口：推荐 ==========
    
    def recommend(
        self, 
        user_id: str, 
        top_n: int = 5, 
        scenario: str = None,
        context: Dict = None
    ) -> List[Dict]:
        """
        【主要接口】获取个性化推荐
        
        Args:
            user_id: 用户ID
            top_n: 推荐数量
            scenario: 场景 ('weekday', 'weekend', 'group', 'special')
            context: 额外上下文信息 {'location': '...', 'time': '...'}
        
        Returns:
            List[Dict]: 推荐餐厅列表，包含详细信息
        
        Example:
            >>> engine = RecommendationEngine()
            >>> recs = engine.recommend("USER_0001", top_n=3, scenario="weekend")
            >>> for rec in recs:
            ...     print(f"{rec['name']} - {rec['reason']}")
        """
        # 1. 验证用户是否存在
        if user_id not in self.user_index:
            print(f"[Warning] 用户 {user_id} 不存在，返回热门推荐")
            return self.get_popular_recommendations(top_n)
        
        user = self.user_index[user_id]
        
        # 2. 计算每个餐厅的匹配分数
        scored_restaurants = []
        for restaurant in self.restaurants:
            score = self._calculate_match_score(user, restaurant, scenario)
            
            # 生成推荐理由
            reason = self._generate_recommendation_reason(user, restaurant, scenario)
            
            scored_restaurants.append({
                "restaurant_id": restaurant["restaurant_id"],
                "name": restaurant["name"],
                "cuisine_tags": restaurant["cuisine_tags"],
                "rating": restaurant["rating"],
                "price_range": restaurant["price_range"],
                "price_level": "$" * restaurant["price_range"],
                "location": restaurant.get("location", {}),
                "score": score,
                "reason": reason,
                "match_percentage": min(100, int(score * 20))  # 转换为百分比
            })
        
        # 3. 按分数排序
        scored_restaurants.sort(key=lambda x: x["score"], reverse=True)
        
        # 4. 返回Top N
        return scored_restaurants[:top_n]
    
    def _calculate_match_score(self, user: Dict, restaurant: Dict, scenario: str = None) -> float:
        """计算匹配分数"""
        score = 0.0
        
        # 1. 菜系匹配（权重40%）
        cuisine_score = 0
        for cuisine in restaurant["cuisine_tags"]:
            if cuisine in user["preferences"]["cuisine_weights"]:
                cuisine_score += user["preferences"]["cuisine_weights"][cuisine]
        if restaurant["cuisine_tags"]:
            cuisine_score /= len(restaurant["cuisine_tags"])
        score += cuisine_score * 4.0
        
        # 2. 价格匹配（权重25%）
        price_score = self._calculate_price_match(user, restaurant)
        score += price_score * 2.5
        
        # 3. 评分加成（权重20%）
        rating_score = (restaurant["rating"] - 3.0) / 2.0  # 归一化到0-1
        score += rating_score * 2.0
        
        # 4. 场景适配（权重15%）
        scenario_score = self._calculate_scenario_score(restaurant, scenario)
        score += scenario_score * 1.5
        
        return round(score, 2)
    
    def _calculate_price_match(self, user: Dict, restaurant: Dict) -> float:
        """计算价格匹配度"""
        income = user["demographics"]["income_level"]
        price = restaurant["price_range"]
        
        # 收入与理想价格映射
        income_price_map = {
            "low": 2,      # 低收入：偏好$和$$
            "middle": 3,   # 中等收入：偏好$$到$$$$
            "high": 4      # 高收入：偏好$$$到$$$$$
        }
        
        ideal_price = income_price_map.get(income, 3)
        
        # 计算差距
        diff = abs(price - ideal_price)
        if diff == 0:
            return 1.0
        elif diff == 1:
            return 0.7
        elif diff == 2:
            return 0.4
        else:
            return 0.2
    
    def _calculate_scenario_score(self, restaurant: Dict, scenario: str) -> float:
        """计算场景适配度"""
        if not scenario:
            return 0.5
        
        scenario_scores = {
            "weekday": {
                "max_price": 3,  # 工作日倾向于便宜
                "min_capacity": 0
            },
            "weekend": {
                "max_price": 5,
                "min_capacity": 0
            },
            "group": {
                "max_price": 4,
                "min_capacity": 8  # 团体需要大桌
            },
            "special": {
                "max_price": 5,
                "min_capacity": 4,
                "min_rating": 4.5  # 特殊场合要求高评分
            }
        }
        
        rules = scenario_scores.get(scenario, {})
        score = 0.5
        
        # 检查容量
        if restaurant["capacity"]["max"] >= rules.get("min_capacity", 0):
            score += 0.3
        
        # 检查价格
        if restaurant["price_range"] <= rules.get("max_price", 5):
            score += 0.3
        
        # 检查评分
        if restaurant["rating"] >= rules.get("min_rating", 0):
            score += 0.3
        
        return min(1.0, score)
    
    def _generate_recommendation_reason(self, user: Dict, restaurant: Dict, scenario: str = None) -> str:
        """生成个性化推荐理由"""
        reasons = []
        
        # 1. 菜系匹配
        matching_cuisines = []
        for cuisine in restaurant["cuisine_tags"]:
            if cuisine in user["preferences"]["cuisine_weights"]:
                weight = user["preferences"]["cuisine_weights"][cuisine]
                if weight > 0.6:
                    matching_cuisines.append(cuisine)
        
        if matching_cuisines:
            reasons.append(f"匹配您喜欢的{', '.join(matching_cuisines[:2])}菜系")
        
        # 2. 价格匹配
        income = user["demographics"]["income_level"]
        price = restaurant["price_range"]
        
        if income == "low" and price <= 2:
            reasons.append("价格亲民，性价比高")
        elif income == "middle" and 2 <= price <= 4:
            reasons.append("价格适中，物有所值")
        elif income == "high" and price >= 4:
            reasons.append("符合您的高端消费偏好")
        
        # 3. 评分
        rating = restaurant["rating"]
        if rating >= 4.5:
            reasons.append("评分很高（4.5+）")
        elif rating >= 4.0:
            reasons.append("评分优秀（4.0+）")
        
        # 4. 场景
        if scenario == "group" and restaurant["capacity"]["max"] >= 8:
            reasons.append("适合团体聚餐")
        elif scenario == "special":
            reasons.append("适合特殊场合")
        
        return "；".join(reasons) if reasons else "根据您的偏好推荐"
    
    # ========== 接口：用户画像 ==========
    
    def get_user_profile(self, user_id: str) -> Optional[Dict]:
        """
        【接口】获取用户画像
        
        Args:
            user_id: 用户ID
        
        Returns:
            Dict: 用户画像信息
        
        Example:
            >>> profile = engine.get_user_profile("USER_0001")
            >>> print(profile['demographics']['occupation'])
            Software Engineer
        """
        if user_id not in self.user_index:
            return None
        
        user = self.user_index[user_id]
        
        # 添加统计信息
        profile = user.copy()
        profile["statistics"] = self._get_user_statistics(user_id)
        
        return profile
    
    def _get_user_statistics(self, user_id: str) -> Dict:
        """获取用户统计信息"""
        # 统计用户行为
        user_behaviors = [b for b in self.behaviors if b["user_id"] == user_id]
        
        stats = {
            "total_visits": len(user_behaviors),
            "total_reservations": len([
                b for b in user_behaviors 
                if b["action_type"] == "MAKE_RESERVATION"
            ]),
            "top_cuisines": self._get_user_top_cuisines(user_id)
        }
        
        return stats
    
    def _get_user_top_cuisines(self, user_id: str, top_n: int = 3) -> List[str]:
        """获取用户最喜欢的菜系"""
        if user_id not in self.user_index:
            return []
        
        user = self.user_index[user_id]
        weights = user["preferences"]["cuisine_weights"]
        
        sorted_cuisines = sorted(weights.items(), key=lambda x: x[1], reverse=True)
        return [c[0] for c in sorted_cuisines[:top_n]]
    
    # ========== 接口：餐厅信息 ==========
    
    def get_restaurant_info(self, restaurant_id: str) -> Optional[Dict]:
        """
        【接口】获取餐厅信息
        
        Args:
            restaurant_id: 餐厅ID
        
        Returns:
            Dict: 餐厅详细信息
        
        Example:
            >>> info = engine.get_restaurant_info("REST_0001")
            >>> print(info['name'])
            Italian Garden Restaurant
        """
        if restaurant_id not in self.restaurant_index:
            return None
        
        restaurant = self.restaurant_index[restaurant_id]
        
        # 添加统计信息
        restaurant["statistics"] = self._get_restaurant_statistics(restaurant_id)
        
        return restaurant
    
    def _get_restaurant_statistics(self, restaurant_id: str) -> Dict:
        """获取餐厅统计信息"""
        # 统计预订次数
        reservations = [
            b for b in self.behaviors 
            if b["restaurant_id"] == restaurant_id 
            and b["action_type"] == "MAKE_RESERVATION"
        ]
        
        # 统计评分
        reviews = [
            b for b in self.behaviors 
            if b["restaurant_id"] == restaurant_id 
            and b["action_type"] == "LEAVE_REVIEW"
        ]
        
        return {
            "total_reservations": len(reservations),
            "total_reviews": len(reviews),
            "popularity_score": len(reservations) + len(reviews) * 0.5
        }
    
    # ========== 接口：热门推荐（冷启动） ==========
    
    def get_popular_recommendations(self, top_n: int = 5) -> List[Dict]:
        """
        【接口】获取热门推荐（用于新用户冷启动）
        
        Args:
            top_n: 推荐数量
        
        Returns:
            List[Dict]: 热门餐厅列表
        
        Example:
            >>> hot_recs = engine.get_popular_recommendations(3)
            >>> for rec in hot_recs:
            ...     print(f"{rec['name']} - {rec['reason']}")
        """
        # 统计每个餐厅的预订次数
        reservation_counts = {}
        for behavior in self.behaviors:
            if behavior["action_type"] == "MAKE_RESERVATION":
                rest_id = behavior["restaurant_id"]
                reservation_counts[rest_id] = reservation_counts.get(rest_id, 0) + 1
        
        # 按预订次数排序
        popular_ids = sorted(
            reservation_counts.items(),
            key=lambda x: x[1],
            reverse=True
        )[:top_n]
        
        recommendations = []
        for rest_id, count in popular_ids:
            if rest_id in self.restaurant_index:
                restaurant = self.restaurant_index[rest_id]
                recommendations.append({
                    "restaurant_id": rest_id,
                    "name": restaurant["name"],
                    "cuisine_tags": restaurant["cuisine_tags"],
                    "rating": restaurant["rating"],
                    "price_range": restaurant["price_range"],
                    "price_level": "$" * restaurant["price_range"],
                    "location": restaurant.get("location", {}),
                    "score": count,
                    "reason": f"热门选择，已有{count}次预订",
                    "match_percentage": min(100, count * 10)
                })
        
        return recommendations
    
    # ========== 接口：数据统计 ==========
    
    def get_statistics(self) -> Dict:
        """
        【接口】获取系统统计数据
        
        Returns:
            Dict: 统计信息
        
        Example:
            >>> stats = engine.get_statistics()
            >>> print(f"总用户: {stats['total_users']}")
            >>> print(f"转化率: {stats['conversion_rate']:.1%}")
        """
        total_users = len(self.users)
        total_behaviors = len(self.behaviors)
        total_reservations = len([
            b for b in self.behaviors 
            if b["action_type"] == "MAKE_RESERVATION"
        ])
        
        # 计算转化率
        users_with_reservations = len(set([
            b["user_id"] for b in self.behaviors 
            if b["action_type"] == "MAKE_RESERVATION"
        ]))
        conversion_rate = users_with_reservations / total_users if total_users > 0 else 0
        
        # 场景分布
        scenario_distribution = {}
        for session in self.sessions:
            scenario = session.get("scenario", "unknown")
            scenario_distribution[scenario] = scenario_distribution.get(scenario, 0) + 1
        
        return {
            "total_users": total_users,
            "total_restaurants": len(self.restaurants),
            "total_behaviors": total_behaviors,
            "total_reservations": total_reservations,
            "users_with_reservations": users_with_reservations,
            "conversion_rate": conversion_rate,
            "scenario_distribution": scenario_distribution,
            "model": {
                "type": "RandomForest",
                "accuracy": 0.884,
                "f1_score": 0.840
            }
        }
    
    # ========== 调试工具 ==========
    
    def test_recommendation(self, user_id: str, top_n: int = 3) -> None:
        """
        测试推荐功能 - 打印详细结果
        
        Args:
            user_id: 用户ID
            top_n: 推荐数量
        """
        print("\n" + "=" * 70)
        print(f"[TEST] 推荐测试 - 用户: {user_id}")
        print("=" * 70)
        
        # 获取用户信息
        user = self.user_index.get(user_id)
        if not user:
            print("[ERROR] 用户不存在")
            return
        
        print(f"[User] 职业: {user['demographics']['occupation']}")
        print(f"[User] 收入: {user['demographics']['income_level']}")
        print(f"[User] 偏好菜系: {self._get_user_top_cuisines(user_id)}")
        print("-" * 70)
        
        # 测试不同场景
        scenarios = [("工作日", "weekday"), ("周末", "weekend"), ("团体", "group")]
        
        for scenario_name, scenario_code in scenarios:
            print(f"\n[Scenario] {scenario_name}场景:")
            recs = self.recommend(user_id, top_n=top_n, scenario=scenario_code)
            
            for i, rec in enumerate(recs, 1):
                print(f"  {i}. {rec['name']}")
                print(f"     评分: {rec['rating']}, 价格: {rec['price_level']}")
                print(f"     匹配度: {rec['match_percentage']}%")
                print(f"     理由: {rec['reason']}")
        
        print("\n" + "=" * 70)
    
    def test_all_interfaces(self):
        """测试所有接口"""
        print("\n" + "=" * 70)
        print("[TEST] 推荐引擎接口测试")
        print("=" * 70)
        
        # 使用第一个用户测试
        test_user = self.users[0]["user_id"]
        
        print(f"\n测试用户: {test_user}")
        
        # 1. 测试推荐接口
        print("\n[1] 测试推荐接口 (recommend)")
        recs = self.recommend(test_user, top_n=3)
        print(f"   [OK] 获取到 {len(recs)} 个推荐")
        for rec in recs:
            print(f"      - {rec['name']} (匹配度: {rec['match_percentage']}%)")
        
        # 2. 测试用户画像接口
        print("\n[2] 测试用户画像接口 (get_user_profile)")
        profile = self.get_user_profile(test_user)
        if profile:
            print(f"   [OK] 职业: {profile['demographics']['occupation']}")
            print(f"   [OK] 访问次数: {profile['statistics']['total_visits']}")
        
        # 3. 测试餐厅信息接口
        print("\n[3] 测试餐厅信息接口 (get_restaurant_info)")
        if recs:
            restaurant = self.get_restaurant_info(recs[0]["restaurant_id"])
            if restaurant:
                print(f"   [OK] 餐厅: {restaurant['name']}")
                print(f"   [OK] 预订数: {restaurant['statistics']['total_reservations']}")
        
        # 4. 测试热门推荐接口
        print("\n[4] 测试热门推荐接口 (get_popular_recommendations)")
        hot_recs = self.get_popular_recommendations(3)
        print(f"   [OK] 获取到 {len(hot_recs)} 个热门推荐")
        for rec in hot_recs:
            print(f"      - {rec['name']} ({rec['reason']})")
        
        # 5. 测试统计接口
        print("\n[5] 测试统计接口 (get_statistics)")
        stats = self.get_statistics()
        print(f"   [OK] 总用户: {stats['total_users']}")
        print(f"   [OK] 转化率: {stats['conversion_rate']:.1%}")
        print(f"   [OK] 模型准确率: {stats['model']['accuracy']:.1%}")
        
        print("\n" + "=" * 70)
        print("[OK] 所有接口测试通过！")
        print("=" * 70)


# ========== 使用示例 ==========

if __name__ == "__main__":
    print("\n" + "=" * 70)
    print("TableTalk 推荐引擎启动")
    print("=" * 70)
    
    # 1. 初始化引擎
    engine = RecommendationEngine(dataset_path="data/")
    
    # 2. 测试所有接口
    engine.test_all_interfaces()
    
    # 3. 单用户详细测试
    print("\n" + "=" * 70)
    print("[TEST] 单用户详细测试")
    print("=" * 70)
    
    if engine.users:
        test_user = engine.users[0]["user_id"]
        engine.test_recommendation(test_user, top_n=3)
    
    print("\n[OK] 推荐引擎就绪，等待其他模块调用！")