# check_data.py - 验证数据
import json
import os

print("=" * 70)
print("验证数据文件")
print("=" * 70)

files = ["restaurants.json", "users.json", "behaviors.json", "sessions.json", "reservations.json"]

for file in files:
    try:
        with open(f"data/{file}", "r", encoding="utf-8") as f:
            data = json.load(f)
        print(f"[OK] {file}: {len(data)} 条")
    except FileNotFoundError:
        print(f"[ERROR] {file}: 不存在")
    except Exception as e:
        print(f"[ERROR] {file}: {e}")

print("=" * 70)